# Simple chartbuilder based on matplotlib library
# Homepage: https://github.com/greentracery/ChartBuilder

__version__ = '1.0'

